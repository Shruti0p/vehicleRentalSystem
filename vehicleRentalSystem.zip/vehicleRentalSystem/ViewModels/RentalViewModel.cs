// File: ViewModels/RentalViewModel.cs

using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using RentalSystem.Models;

namespace RentalSystem.ViewModels
{
    public class RentalViewModel
    {
        // Rental Properties
        public int Id { get; set; }

    [Required]
    [Display(Name = "Customer Name")]
    public string CustomerName { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.DateTime)]
    [Display(Name = "Start Date and Time")]
    public DateTime RentalStartDate { get; set; } = DateTime.Now.AddHours(1);

    [Required]
    [DataType(DataType.DateTime)]
    [Display(Name = "End Date and Time")]
    public DateTime RentalEndDate { get; set; } = DateTime.Now.AddHours(25);

        // Relationship Properties
        [Required]
        [Display(Name = "Select Vehicle")]
        public int VehicleId { get; set; }

    // List of AVAILABLE vehicles for the dropdown
    // This may be null in some flows; controllers will populate it when rendering views.
    public SelectList? AvailableVehicles { get; set; }
    }
}