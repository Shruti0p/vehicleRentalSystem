using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RentalSystem.Data;
using RentalSystem.Models;
using RentalSystem.ViewModels;
using System.Linq;
using System.Threading.Tasks;
using System; // Ensure System is included for DateTime and Math
using Microsoft.AspNetCore.Authorization;

namespace RentalSystem.Controllers
{
    public class RentalsController : Controller
    {
        private readonly RentalSystemContext _context;

        public RentalsController(RentalSystemContext context)
        {
            _context = context;
        }

    // GET: Rentals (Admin)
    // Admin: Lists all rentals and uses .Include()
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Index()
        {
            // Business Logic: Must display the Vehicle Make and Model using Include
            var rentals = await _context.Rentals
                .Include(r => r.Vehicle)
                .ToListAsync();

            return View(rentals);
        }

        // GET: Rentals/MyRentals
        // Shows current user their bookings (current and history)
        [Authorize]
        public async Task<IActionResult> MyRentals()
        {
            var username = User?.Identity?.Name ?? string.Empty;
            var rentals = await _context.Rentals
                .Include(r => r.Vehicle)
                .Where(r => r.CustomerName == username)
                .OrderByDescending(r => r.RentalStartDate)
                .ToListAsync();

            return View(rentals);
        }

    // GET: Rentals/Create
    // Implements Create: Displays the booking form (requires authentication)
    [Authorize]
    public async Task<IActionResult> Create()
        {
            // Business Logic: Only vehicles with Status = 'Available' should be selectable
            var availableVehicles = await _context.Vehicles
                .Where(v => v.Status == "Available")
                .ToListAsync();

            var viewModel = new RentalViewModel
            {
                AvailableVehicles = new SelectList(availableVehicles, "Id", "MakeModelYear")
            };
            return View(viewModel);
        }

        // POST: Rentals/Create
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RentalViewModel rentalVm)
        {
            // Basic date validation
            if (rentalVm.RentalStartDate > rentalVm.RentalEndDate)
            {
                ModelState.AddModelError("", "The Rental Start Date cannot be after the End Date.");
            }
            if (rentalVm.RentalStartDate < DateTime.Now)
            {
                ModelState.AddModelError("RentalStartDate", "Bookings cannot be made for past dates or times.");
            }

            // Check overlapping bookings for the same vehicle
            if (rentalVm.VehicleId != 0)
            {
                var overlap = await _context.Rentals
                    .AnyAsync(r => r.VehicleId == rentalVm.VehicleId && r.RentalStartDate <= rentalVm.RentalEndDate && r.RentalEndDate >= rentalVm.RentalStartDate);

                if (overlap)
                {
                    ModelState.AddModelError("", "The selected vehicle is already booked for the chosen date range.");
                }
            }

            if (ModelState.IsValid)
            {
                // 1. Fetch Vehicle to get DailyRate and update Status
                var vehicle = await _context.Vehicles.FindAsync(rentalVm.VehicleId);

                // Re-validate availability
                if (vehicle == null || vehicle.Status != "Available")
                {
                    ModelState.AddModelError("VehicleId", "The selected vehicle is no longer available.");
                    // Skip to the end to reload view model
                }
                else
                {
                    // Calculate Days Rented
                    var totalDays = (rentalVm.RentalEndDate - rentalVm.RentalStartDate).TotalDays;
                    // Ensure at least 1 full day is charged 
                    var daysRented = Math.Max(1, (decimal)Math.Ceiling(totalDays)); 

                    // 2. Business Logic: Calculate and save the TotalCost
                    var rental = new Rental
                    {
                        // Prefer authenticated username when available
                        CustomerName = User?.Identity?.IsAuthenticated == true ? User.Identity.Name ?? rentalVm.CustomerName : rentalVm.CustomerName,
                        RentalStartDate = rentalVm.RentalStartDate,
                        RentalEndDate = rentalVm.RentalEndDate,
                        VehicleId = rentalVm.VehicleId,
                        // TotalCost = DailyRate * (Days Rented)
                        TotalCost = vehicle.DailyRate * daysRented 
                    };

                    // 3. Business Logic: On successful save, update the selected Vehicle's Status MUST be updated to 'Rented'
                    // Only set vehicle status to Rented if the booking starts now or earlier (i.e., it's actively rented)
                    if (rentalVm.RentalStartDate <= DateTime.Today)
                    {
                        vehicle.Status = "Rented";
                        _context.Update(vehicle);
                    }
                    
                    _context.Add(rental);
                    await _context.SaveChangesAsync();

                    // Redirect admins to admin index, regular users to their MyRentals page
                    if (User?.IsInRole("Admin") == true)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    else
                    {
                        return RedirectToAction(nameof(MyRentals));
                    }
                }
            }

            // If model state is not valid, reload available vehicles for the view
            var availableVehicles = await _context.Vehicles.Where(v => v.Status == "Available").ToListAsync();
            rentalVm.AvailableVehicles = new SelectList(availableVehicles, "Id", "MakeModelYear");
            return View(rentalVm);
        }

        // POST: Rentals/Return/5
        // Implements Update (Return): An explicit action to return the vehicle
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Return(int id)
        {
            var rental = await _context.Rentals.Include(r => r.Vehicle).FirstOrDefaultAsync(r => r.Id == id);

            if (rental == null || rental.Vehicle == null)
            {
                TempData["ErrorMessage"] = "Rental or associated vehicle not found.";
                return RedirectToAction(nameof(MyRentals));
            }

            // Only allow the owner or an Admin to mark as returned
            var username = User?.Identity?.Name ?? string.Empty;
            var isAdmin = User?.IsInRole("Admin") == true;
            if (!isAdmin && !string.Equals(rental.CustomerName, username, StringComparison.OrdinalIgnoreCase))
            {
                return Forbid();
            }

            // Update the associated Vehicle's Status back to 'Available'
            rental.Vehicle.Status = "Available";
            _context.Update(rental.Vehicle);

            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = $"Vehicle {rental.Vehicle.Make} {rental.Vehicle.Model} returned successfully! Status is now Available.";

            // Redirect back to an appropriate area: admin -> Index, user -> MyRentals
            if (isAdmin)
            {
                return RedirectToAction(nameof(Index));
            }
            return RedirectToAction(nameof(MyRentals));
        }

        // POST: Rentals/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var rental = await _context.Rentals.Include(r => r.Vehicle).FirstOrDefaultAsync(r => r.Id == id);

            if (rental == null) return RedirectToAction(nameof(Index));

            // Business Logic: Check if it's a future booking (since the spec allows canceling a future booking)
            if (rental.RentalEndDate < DateTime.Now)
            {
                TempData["ErrorMessage"] = "Cannot cancel a past or ongoing rental. Use the Return action instead.";
                return RedirectToAction(nameof(Index));
            }

            // Business Logic: If the rental is deleted, the associated Vehicle's Status MUST be reset to 'Available'
            if (rental.Vehicle != null)
            {
                rental.Vehicle.Status = "Available";
                _context.Update(rental.Vehicle);
            }

            _context.Rentals.Remove(rental);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Rental booking successfully canceled, and vehicle status reset to Available.";

            // Redirect appropriately based on role
            var isAdmin2 = User?.IsInRole("Admin") == true;
            if (isAdmin2)
            {
                return RedirectToAction(nameof(Index));
            }
            return RedirectToAction(nameof(MyRentals));
        }
    }
}