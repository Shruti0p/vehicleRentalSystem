using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RentalSystem.Data;
using System.Threading.Tasks;

namespace RentalSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly RentalSystemContext _context;

        public HomeController(RentalSystemContext context)
        {
            _context = context;
        }

        // GET: /Home/Index (Dashboard)
        public async Task<IActionResult> Index()
        {
            // Business Logic: Fetch summary data for the Dashboard (UI Requirement 1)

            // 1. Total Available Vehicles
            // Count vehicles where Status is 'Available'
            ViewBag.TotalAvailable = await _context.Vehicles
                .CountAsync(v => v.Status == "Available");

            // 2. Total Current Rentals
            // Count vehicles where Status is 'Rented' as a proxy for current, active rentals
            ViewBag.TotalRented = await _context.Vehicles
                .CountAsync(v => v.Status == "Rented");

            return View();
        }
        
        // Default Error Action
        public IActionResult Error()
        {
            return View();
        }
    }
}