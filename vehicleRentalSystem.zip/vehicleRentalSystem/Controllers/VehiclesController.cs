using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using RentalSystem.Data;
using RentalSystem.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Globalization;
using System.Collections.Generic;

namespace RentalSystem.Controllers
{
    public class VehiclesController : Controller
    {
        private readonly RentalSystemContext _context;

        public VehiclesController(RentalSystemContext context)
        {
            _context = context;
        }

    // GET: Vehicles
    [AllowAnonymous]
        // Implements Read: Lists all vehicles with filtering by Status
        public async Task<IActionResult> Index(string statusFilter)
        {
            // Simple filtering logic
            IQueryable<Vehicle> vehicles = _context.Vehicles;

            if (!string.IsNullOrEmpty(statusFilter) && statusFilter != "All")
            {
                vehicles = vehicles.Where(v => v.Status == statusFilter);
            }

            ViewBag.CurrentFilter = statusFilter;
            return View(await vehicles.ToListAsync()); 
        }

        // GET: Vehicles/Create
        // Implements Create: Displays the form
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

    // POST: Vehicles/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create([Bind("Make,Model,Year,DailyRate,HourlyRate")] Vehicle vehicle)
        {
            if (ModelState.IsValid)
            {
                // Business Logic: Status must default to Available
                vehicle.Status = "Available";
                _context.Add(vehicle);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(vehicle);
        }

    // GET: Vehicles/Edit/5
        // Implements Update: Displays the edit form
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle == null) return NotFound();
            
            return View(vehicle);
        }

    // POST: Vehicles/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Edit(int id, [Bind("Id,Make,Model,Year,DailyRate,HourlyRate,Status")] Vehicle updatedVehicle)
        {
            if (id != updatedVehicle.Id) return NotFound();

            if (ModelState.IsValid)
            {
                var vehicle = await _context.Vehicles
                    .AsNoTracking() 
                    .FirstOrDefaultAsync(m => m.Id == id);

                if (vehicle == null) return NotFound();

                // --- Business Logic Validation for Update ---
                if (vehicle.Status == "Rented")
                {
                    // Validation: Cannot change Make/Model/Year/Rate if Status is Rented
                    if (vehicle.Make != updatedVehicle.Make || 
                        vehicle.Model != updatedVehicle.Model ||
                        vehicle.Year != updatedVehicle.Year || 
                        vehicle.DailyRate != updatedVehicle.DailyRate)
                    {
                        ModelState.AddModelError("", "Cannot change Make, Model, Year, or Daily Rate while the vehicle is Rented.");
                        return View(updatedVehicle);
                    }
                    
                    // Must allow changing Status to Maintenance at any time.
                    // We prevent changing Rented to Available here, as that must happen via the Return action.
                    if (updatedVehicle.Status == "Available" && vehicle.Status == "Rented")
                    {
                         ModelState.AddModelError("Status", "Cannot change Status from Rented back to Available via the Edit form. Use the Rental Return action instead.");
                         return View(updatedVehicle);
                    }
                }
                
                try
                {
                    // Attach the updated object and mark it as modified
                    _context.Entry(updatedVehicle).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Vehicles.Any(e => e.Id == id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(updatedVehicle);
        }

    // GET: Vehicles/Delete/5
    [Authorize(Roles = "Admin")]
        // Implements Delete: Displays confirmation
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var vehicle = await _context.Vehicles
                .FirstOrDefaultAsync(m => m.Id == id);

            if (vehicle == null) return NotFound();

            // Check business logic before displaying the delete confirmation
            var activeRentals = await _context.Rentals
                // A rental is considered 'active/unreturned' if the end date is in the future or today
                .Where(r => r.VehicleId == id && r.RentalEndDate >= DateTime.Today)
                .CountAsync();

            // Business Logic: Prevent deletion if Status is Rented or active rentals exist
            if (vehicle.Status == "Rented" || activeRentals > 0)
            {
                ViewBag.CanDelete = false;
                ViewBag.DeletionReason = "Cannot delete: Vehicle is currently Rented or has active, unreturned bookings linked to it.";
            }
            else
            {
                ViewBag.CanDelete = true;
            }

            return View(vehicle);
        }

    // POST: Vehicles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle == null) return RedirectToAction(nameof(Index));

            // Re-check business logic before deletion
            var activeRentals = await _context.Rentals
                .Where(r => r.VehicleId == id && r.RentalEndDate >= DateTime.Today)
                .CountAsync();

            if (vehicle.Status == "Rented" || activeRentals > 0)
            {
                // Block deletion again if somehow the status changed between GET and POST
                TempData["ErrorMessage"] = "Deletion failed: Vehicle is Rented or has active bookings.";
                return RedirectToAction(nameof(Index));
            }

            _context.Vehicles.Remove(vehicle);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Vehicles/Import
        [Authorize(Roles = "Admin")]
        // Displays a simple CSV import form: expected columns: Make,Model,Year,DailyRate
        public IActionResult Import()
        {
            return View();
        }

    // POST: Vehicles/Import
        [HttpPost]
        [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Import(IFormFile csvFile)
        {
            if (csvFile == null || csvFile.Length == 0)
            {
                ModelState.AddModelError(string.Empty, "Please select a CSV file to import.");
                return View();
            }

            var imported = new List<Vehicle>();

            using (var reader = new StreamReader(csvFile.OpenReadStream()))
            {
                while (!reader.EndOfStream)
                {
                    var line = await reader.ReadLineAsync();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    // Simple CSV parsing: Make,Model,Year,DailyRate
                    var parts = line.Split(',');
                    if (parts.Length < 4) continue;

                    var make = parts[0].Trim();
                    var model = parts[1].Trim();
                    var year = int.TryParse(parts[2].Trim(), out var y) ? y : 0;
                    var rate = decimal.TryParse(parts[3].Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out var r) ? r : 0m;
                    var hourly = 0m;
                    if (parts.Length >= 5)
                    {
                        hourly = decimal.TryParse(parts[4].Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out var h) ? h : 0m;
                    }

                    if (string.IsNullOrEmpty(make) || string.IsNullOrEmpty(model) || year <= 0) continue;

                    imported.Add(new Vehicle
                    {
                        Make = make,
                        Model = model,
                        Year = year,
                        DailyRate = rate,
                        HourlyRate = hourly,
                        Status = "Available"
                    });
                }
            }

            if (imported.Count > 0)
            {
                _context.Vehicles.AddRange(imported);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Imported {imported.Count} vehicles.";
            }
            else
            {
                TempData["ErrorMessage"] = "No valid vehicles were found in the uploaded CSV.";
            }

            return RedirectToAction(nameof(Index));
        }
    }
}