using Microsoft.EntityFrameworkCore;
using RentalSystem.Data;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add simple cookie authentication for demo purposes. This allows signing in as a User or Admin via a demo login page.
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });

// --- Database Configuration for XAMPP (MySQL/MariaDB) ---

// 1. Get the connection string from configuration (appsettings.json)
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") 
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// 2. Register the DbContext to use MySQL with Pomelo provider
builder.Services.AddDbContext<RentalSystemContext>(options =>
    options.UseMySql(
        connectionString,
        // Automatically detect the server version (required by Pomelo)
        ServerVersion.AutoDetect(connectionString),
        mysqlOptions =>
        {
            // Enable retries for transient failures (optional but recommended)
            mysqlOptions.EnableRetryOnFailure();
            // Note: Removed the previous CharSetBehavior line that caused the error.
        }
    ));

// --- End Database Configuration ---


var app = builder.Build();

// Seed sample vehicles for demo if none exist.
using (var scope = app.Services.CreateScope())
{
    try
    {
        var db = scope.ServiceProvider.GetRequiredService<RentalSystem.Data.RentalSystemContext>();
        if (!db.Vehicles.Any())
        {
            db.Vehicles.AddRange(
                new RentalSystem.Models.Vehicle { Make = "Toyota", Model = "Corolla", Year = 2018, DailyRate = 49.99m, HourlyRate = 7.50m, Status = "Available" },
                new RentalSystem.Models.Vehicle { Make = "Honda", Model = "Civic", Year = 2020, DailyRate = 59.50m, HourlyRate = 8.50m, Status = "Available" },
                new RentalSystem.Models.Vehicle { Make = "Ford", Model = "Focus", Year = 2019, DailyRate = 54.00m, HourlyRate = 8.00m, Status = "Available" },
                new RentalSystem.Models.Vehicle { Make = "Hyundai", Model = "Elantra", Year = 2021, DailyRate = 62.00m, HourlyRate = 9.00m, Status = "Available" },
                new RentalSystem.Models.Vehicle { Make = "Suzuki", Model = "Swift", Year = 2017, DailyRate = 39.99m, HourlyRate = 6.00m, Status = "Available" }
            );
            db.SaveChanges();
        }
    }
    catch (Exception ex)
    {
        // If seeding fails in some environments (missing DB), don't crash the app during startup.
        var logger = scope.ServiceProvider.GetService<ILogger<Program>>();
        logger?.LogWarning(ex, "Seeding sample vehicles failed.");
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();