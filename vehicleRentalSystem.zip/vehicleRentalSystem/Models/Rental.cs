using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RentalSystem.Models
{
    public class Rental
    {
        // Primary Key
        public int Id { get; set; }

        // Required Properties
    [Required]
    public string CustomerName { get; set; } = string.Empty;

        [Required]
        public DateTime RentalStartDate { get; set; }

        [Required]
        public DateTime RentalEndDate { get; set; }

        // Calculated Property: DailyRate * (Days Rented)
        [Column(TypeName = "decimal(18, 2)")]
        public decimal TotalCost { get; set; }

        // Foreign Key: Links to the Vehicle
        public int VehicleId { get; set; }

    // Navigation Property: The associated Vehicle object
    // Vehicle can be null when the Rental instance is created and EF will populate it when needed.
    public Vehicle? Vehicle { get; set; }
    }
}