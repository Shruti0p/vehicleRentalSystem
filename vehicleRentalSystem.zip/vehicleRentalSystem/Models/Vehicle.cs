using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RentalSystem.Models
{
    public class Vehicle
    {
        // Primary Key
        public int Id { get; set; }

        // Required Properties
    [Required]
    public string Make { get; set; } = string.Empty;

    [Required]
    public string Model { get; set; } = string.Empty;

        [Required]
        public int Year { get; set; }

        [Required]
        [Column(TypeName = "decimal(18, 2)")] // Recommended for currency/rates
        public decimal DailyRate { get; set; }

    // Optional hourly rate for customers who rent by the hour
    [Column(TypeName = "decimal(18, 2)")]
    public decimal HourlyRate { get; set; } = 0m;

        // Crucial Status: Must be one of: Available, Rented, Maintenance
        [Required]
        public string Status { get; set; } = "Available"; // Defaults to Available

        // Navigation Property: List of associated rentals
        public ICollection<Rental> Rentals { get; set; } = new List<Rental>();
        
        // --- Helper Property for Views and Controllers ---
        // Used by RentalsController to display options in the SelectList/Dropdown.
        [NotMapped] // Tells Entity Framework Core NOT to map this property to a database column.
        public string MakeModelYear => $"{Make} {Model} ({Year}) - {DailyRate:C}";
    }
}